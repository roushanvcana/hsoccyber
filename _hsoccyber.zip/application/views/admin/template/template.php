<?php 
 $this->load->view('admin/template/header');
 $this->load->view($main_content);
 $this->load->view('admin/template/footer');
?>