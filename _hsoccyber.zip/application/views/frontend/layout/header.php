<!doctype html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<title>Hsoc Cyber</title>
	
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<script>
	const navbarMenu = document.getElementById("menu");
const burgerMenu = document.getElementById("burger");
const bgOverlay = document.getElementById("overlay");

// Show Menu when Click the Burger
// Hide Menu when Click the Overlay
if (burgerMenu && navbarMenu && bgOverlay) {
	burgerMenu.addEventListener("click", () => {
		navbarMenu.classList.toggle("is-active");
		bgOverlay.classList.toggle("is-active");
	});

	bgOverlay.addEventListener("click", () => {
		navbarMenu.classList.toggle("is-active");
		bgOverlay.classList.toggle("is-active");
	});
}

// Hide Menu when Click the Links
document.querySelectorAll(".menu-link").forEach((link) => {
	link.addEventListener("click", () => {
		navbarMenu.classList.remove("is-active");
		bgOverlay.classList.remove("is-active");
	});
});
	</script>
<link href="https://fonts.googleapis.com/css2?family=Hina+Mincho&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>design/wp-content/plugins/elementor/assets/css/bootstrap.css"/>
<!--<link rel='stylesheet' id='bdt-uikit-css'  href='<?php echo base_url(); ?>design/wp-content/plugins/bdthemes-element-pack-lite/assets/css/bdt-uikitcf1b.css?ver=3.2' type='text/css' media='all' />
<link rel='stylesheet' id='element-pack-site-css'  href='<?php echo base_url(); ?>design/wp-content/plugins/bdthemes-element-pack-lite/assets/css/element-pack-site3d36.css?ver=3.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='prime-slider-site-css'  href='<?php echo base_url(); ?>design/wp-content/plugins/bdthemes-prime-slider-lite/assets/css/prime-slider-site3c94.css?ver=2.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='wp-includes/css/dist/block-library/style.min080f.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='template-kit-export-css'  href='<?php echo base_url(); ?>design/wp-content/plugins/template-kit-export/public/assets/css/template-kit-export-public.min365c.css?ver=1.0.21' type='text/css' media='all' />-->
<link rel='stylesheet' id='hello-elementor-css'  href='<?php echo base_url(); ?>design/wp-content/themes/hello-elementor/style.min8066.css?ver=2.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='hello-elementor-theme-style-css'  href='<?php echo base_url(); ?>design/wp-content/themes/hello-elementor/theme.min8066.css?ver=2.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='<?php echo base_url(); ?>design/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min05c8.css?ver=5.13.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='<?php echo base_url(); ?>design/wp-content/plugins/elementor/assets/css/frontend.mina7da.css?ver=3.4.7' type='text/css' media='all' />
<!--<style id='elementor-frontend-inline-css' type='text/css'>
@font-face {
	font-family: eicons;
	src: url(https://demo.moxcreative.com/byte/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.eot?5.10.0);
	src: url(https://demo.moxcreative.com/byte/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.eot?5.10.0#iefix) format("embedded-opentype"), url(https://demo.moxcreative.com/byte/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff2?5.10.0) format("woff2"), url(https://demo.moxcreative.com/byte/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff?5.10.0) format("woff"), url(https://demo.moxcreative.com/byte/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.ttf?5.10.0) format("truetype"), url(https://demo.moxcreative.com/byte/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.svg?5.10.0#eicon) format("svg");
	font-weight: 400;
	font-style: normal
}
</style>-->
<link rel='stylesheet' id='elementor-post-3-css'  href='<?php echo base_url();?>design/wp-content/uploads/sites/48/elementor/css/post-3b595.css?ver=1637060703' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='<?php echo base_url();?>design/wp-content/plugins/elementor-pro/assets/css/frontend.minee9a.css?ver=3.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='ooohboi-steroids-styles-css'  href='<?php echo base_url();?>design/wp-content/plugins/ooohboi-steroids-for-elementor/assets/css/maine45b.css?ver=1.8.103052021' type='text/css' media='all' />
<link rel='stylesheet' id='void-whmcse-css'  href='<?php echo base_url();?>design/wp-content/plugins/void-elementor-whmcs-elements/assets/css/style080f.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css'  href='<?php echo base_url();?>design/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min1c9b.css?ver=4.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css'  href='<?php echo base_url();?>design/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min1845.css?ver=4.9.6' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-798-css'  href='<?php echo base_url();?>design/wp-content/uploads/sites/48/elementor/css/post-79801f5.css?ver=1637062368' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-53-css'  href='<?php echo base_url();?>design/wp-content/uploads/sites/48/elementor/css/post-53606c.css?ver=1637060704' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-72-css'  href='<?php echo base_url();?>design/wp-content/uploads/sites/48/elementor/css/post-72606c.css?ver=1637060704' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-ekiticons-css'  href='<?php echo base_url();?>design/wp-content/plugins/modules/elementskit-icon-pack/assets/css/ekiticons8d5a.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-css'  href='<?php echo base_url();?>design/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles8d5a.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-responsive-css'  href='<?php echo base_url();?>design/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive8d5a.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CHeebo%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CExo+2%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css'  href='<?php echo base_url();?>design/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3' type='text/css' media='all' />
<!--<link rel='stylesheet' id='elementor-icons-fa-brands-css'  href='<?php echo base_url();?>design/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min52d5.css?ver=5.15.3' type='text/css' media='all' />-->
<script type='text/javascript' src='<?php echo base_url();?>design/wp-includes/js/jquery/jquery.minaf6c.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='<?php echo base_url();?>design/wp-includes/js/jquery/jquery-migrate.mind617.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='<?php echo base_url();?>design/wp-content/plugins/template-kit-export/public/assets/js/template-kit-export-public.min365c.js?ver=1.0.21' id='template-kit-export-js'></script>
<script type='text/javascript' src='<?php echo base_url();?>design/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min1845.js?ver=4.9.6' id='font-awesome-4-shim-js'></script>
<script type='text/javascript' src='<?php echo base_url();?>design/wp-content/plugins/elementor/assets/js/preloaded-modules.mina7da.js?ver=3.4.7' id='preloaded-modules-js'></script>


</head>
<body class="envato_tk_templates-template envato_tk_templates-template-elementor_header_footer single single-envato_tk_templates postid-798 elementor-default elementor-template-full-width elementor-kit-3 elementor-page elementor-page-798">
		<div data-elementor-type="header" data-elementor-id="53" class="elementor elementor-53 elementor-location-header" data-elementor-settings="[]">
 <div class="elementor-section-wrap">
  <section class="ob-is-breaking-bad elementor-section elementor-top-section elementor-element elementor-element-677e228 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="677e228" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;,&quot;_ob_bbad_use_it&quot;:&quot;yes&quot;,&quot;_ob_bbad_sssic_use&quot;:&quot;no&quot;,&quot;_ob_glider_is_slider&quot;:&quot;no&quot;}">
   <div class="elementor-container elementor-column-gap-default">
    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-d9b0db1" data-id="d9b0db1" data-element_type="column" data-settings="{&quot;_ob_bbad_is_stalker&quot;:&quot;no&quot;,&quot;_ob_teleporter_use&quot;:false,&quot;_ob_column_hoveranimator&quot;:&quot;no&quot;,&quot;_ob_column_has_pseudo&quot;:&quot;no&quot;}">
     <div class="elementor-widget-wrap elementor-element-populated">
      <div class="elementor-element elementor-element-767c95b elementor-widget elementor-widget-image" data-id="767c95b" data-element_type="widget" data-settings="{&quot;_ob_photomorph_use&quot;:&quot;no&quot;,&quot;_ob_perspektive_use&quot;:&quot;no&quot;,&quot;_ob_shadough_use&quot;:&quot;no&quot;,&quot;_ob_allow_hoveranimator&quot;:&quot;no&quot;,&quot;_ob_widget_stalker_use&quot;:&quot;no&quot;}" data-widget_type="image.default">
       <div class="elementor-widget-container header-logo"> <a href="index.html"> <img src="<?php echo base_url();?>design/wp-content/uploads/sites/48/elementor/thumbs/Comp_7.gif" title="Hsoc" alt="Hsoc" /> </a> </div>
      </div>
     </div>
    </div>
    <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-c95780e" data-id="c95780e" data-element_type="column" data-settings="{&quot;_ob_bbad_is_stalker&quot;:&quot;no&quot;,&quot;_ob_teleporter_use&quot;:false,&quot;_ob_column_hoveranimator&quot;:&quot;no&quot;,&quot;_ob_column_has_pseudo&quot;:&quot;no&quot;}">
     <div class="elementor-widget-wrap elementor-element-populated">
      <div class="elementor-element elementor-element-0f887b0 elementor-nav-menu__align-right elementor-nav-menu--indicator-angle elementor-nav-menu--stretch elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="0f887b0" data-element_type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;,&quot;_ob_perspektive_use&quot;:&quot;no&quot;,&quot;_ob_shadough_use&quot;:&quot;no&quot;,&quot;_ob_allow_hoveranimator&quot;:&quot;no&quot;,&quot;_ob_widget_stalker_use&quot;:&quot;no&quot;}" data-widget_type="nav-menu.default">
       <div class="elementor-widget-container">
        <nav role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-none">
         <ul id="menu-1-0f887b0" class="elementor-nav-menu">
          <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-6 res-hover-clr"><a href="<?php echo site_url("/home"); ?>" aria-current="page" class="elementor-item elementor-item-active">Home</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8"><a href="<?php echo site_url("/about"); ?>" class="elementor-item">About Us</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10"><a href="<?php echo site_url("/services"); ?>" class="elementor-item">Service</a>
        
          </li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-14"><a href="<?php echo site_url("/contact"); ?>" class="elementor-item">Contact Us</a></li>

         </ul>
        </nav>
        <div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false"> <i class="fas fa-bars font-awesome-free bg-white"></i> <span class="elementor-screen-only">Menu</span> </div>
        <nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true">
         <ul id="menu-2-0f887b0" class="elementor-nav-menu">
          <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-6"><a href="index.html" aria-current="page" class="elementor-item elementor-item-active">Home</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8"><a href="#" class="elementor-item">About Us</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10"><a href="#" class="elementor-item">Service</a>
          </li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-14"><a href="#" class="elementor-item">Contact Us</a></li>
>
         </ul>
        </nav>
       </div>
      </div>
     </div>
    </div>
<!--
    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-4a2b7cb elementor-hidden-phone" data-id="4a2b7cb" data-element_type="column" data-settings="{&quot;_ob_bbad_is_stalker&quot;:&quot;no&quot;,&quot;_ob_teleporter_use&quot;:false,&quot;_ob_column_hoveranimator&quot;:&quot;no&quot;,&quot;_ob_column_has_pseudo&quot;:&quot;no&quot;}">
     <div class="elementor-widget-wrap elementor-element-populated">
      <div class="elementor-element elementor-element-3a67d8a elementor-align-right elementor-widget elementor-widget-button" data-id="3a67d8a" data-element_type="widget" data-settings="{&quot;_ob_butterbutton_use_it&quot;:&quot;no&quot;,&quot;_ob_perspektive_use&quot;:&quot;no&quot;,&quot;_ob_shadough_use&quot;:&quot;no&quot;,&quot;_ob_allow_hoveranimator&quot;:&quot;no&quot;,&quot;_ob_widget_stalker_use&quot;:&quot;no&quot;}" data-widget_type="button.default">
       <div class="elementor-widget-container">
        <div class="elementor-button-wrapper"> <a href="#" class="elementor-button-link elementor-button elementor-size-md" role="button"> <span class="elementor-button-content-wrapper"> <span class="elementor-button-text">Contact Us</span> </span> </a> </div>
       </div>
      </div>
     </div>
    </div>
-->
   </div>
  </section>
 </div>
</div>