<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Syllabus extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_Model');
    }

    public function index()
    {
        $data['syllabus_list'] =  $this->db->query('select * from manage_syllabus')->result_array(); 
         
        $data['main_content'] = 'admin/syllabus/syllabus-list';        
        $this->load->view('admin/template/template',$data);
    }

    public function add_syllabus()
    {
        if($this->input->post()) {
            $syllabus = array(
                    "title" => $this->input->post('title'),
                    "description" => $this->input->post('description'),
                    "status" => 1,                 
                    "entry_by" => 1,                 
                     "ip_add" => $this->input->ip_address(),
                );
            
            if (!empty($_FILES["image"]["name"])) {
                $name = 'IMG' . "-" . rand(1000, 100000).".".$_FILES["image"]["name"];
                $tmp_name = $_FILES["image"]["tmp_name"];
                $error = $_FILES["image"]["error"];
                $path = 'uploads/gallery-image/'. $name;
                move_uploaded_file($tmp_name, $path);
                $syllabus['image'] = $name;
            }
            $insert = $this->db->insert('manage_syllabus', $syllabus);  
                      
            if ($insert) {
                $this->session->set_flashdata('success', 'Syllabus Successfully Saved');
                redirect(site_url().'syllabus-list');
            } else {
                $this->session->set_flashdata('success', 'Some error occured ');
                redirect(site_url().'syllabus-list');
            }
        }           
        $data['main_content'] = 'admin/syllabus/add_syllabus';        
        $this->load->view('admin/template/template',$data);
    }

    public function edit_syllabus($id)
    {
        if($this->input->post()) {
            $syllabus = array(
                    "title" => $this->input->post('title'),
                    "description" => $this->input->post('description'),
                    "status" => 1,                 
                    "entry_by" => 1,                 
                     "ip_add" => $this->input->ip_address(),
                );
            
            if (!empty($_FILES["image"]["name"])) {
                $name = 'IMG' . "-" . rand(1000, 100000).".".$_FILES["image"]["name"];
                $tmp_name = $_FILES["image"]["tmp_name"];
                $error = $_FILES["image"]["error"];
                $path = 'uploads/gallery-image/'. $name;
                move_uploaded_file($tmp_name, $path);
                $syllabus['image'] = $name;
                
            }      

            
            $insert = $this->db->update('manage_syllabus',$syllabus, array('id' => $id));          
            if($insert){
                $this->session->set_flashdata('success', 'Syllabus Successfully updated....');
                redirect(site_url().'syllabus-list');
            }else{
                $this->session->set_flashdata('success', 'Some error occured ');
                redirect(site_url().'syllabus-list');
            }
        }     
        $data['getValue'] = $this->db->query('select * from manage_syllabus where id="'.$id.'"')->row_array();      
        $data['main_content'] = 'admin/syllabus/add_syllabus';        
        $this->load->view('admin/template/template',$data);
    }

    public function delete_syllabus($id)
    {
        $del = $this->db->delete('manage_syllabus', array('id' => $id));
        if(!empty($del)){
            redirect(site_url().'syllabus-list');
        }
    }

}

/* End of file Syllabus.php */


?>