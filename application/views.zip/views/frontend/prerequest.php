
<?php $this->load->view('frontend/layout/header'); ?>
<div data-elementor-type="wp-post" data-elementor-id="469" class="elementor elementor-469" data-elementor-settings="[]">
 <div class="elementor-section-wrap">
  <section class="ob-is-breaking-bad elementor-section elementor-top-section elementor-element elementor-element-7e90c9e elementor-section-boxed elementor-section-height-default elementor-section-height-default">
   <div class="elementor-background-overlay"></div>
   <div class="elementor-container elementor-column-gap-default">
    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ec04429" >
     <div class="elementor-widget-wrap elementor-element-populated">
      <div class="elementor-element elementor-element-837fb42 ob-harakiri-inherit elementor-widget elementor-widget-heading">
       <div class="elementor-widget-container">
        <h1 class="elementor-heading-title elementor-size-default">Prerequisites</h1>
       </div>
      </div>
      <div class="elementor-element elementor-element-cede374 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list">
       <div class="elementor-widget-container">
        <ul class="elementor-icon-list-items elementor-inline-items">
         <li class="elementor-icon-list-item elementor-inline-item"> <span class="elementor-icon-list-text">Home</span> </li>
         <li class="elementor-icon-list-item elementor-inline-item"> <span class="elementor-icon-list-icon icon-align"> <i class="fas fa-arrow-right font-awesome-pro"></i> <span class="elementor-icon-list-text">Prerequisites</span> </li>
        </ul>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>

	

<?php $this->load->view('frontend/layout/footer'); ?>