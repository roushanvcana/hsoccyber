
<?php $this->load->view('frontend/layout/header');
//print_r($about);
?>
<div data-elementor-type="wp-post" data-elementor-id="469" class="elementor elementor-469" data-elementor-settings="[]">
 <div class="elementor-section-wrap">
  <section class="ob-is-breaking-bad elementor-section elementor-top-section elementor-element elementor-element-7e90c9e elementor-section-boxed elementor-section-height-default elementor-section-height-default">
   <div class="elementor-background-overlay"></div>
   <div class="elementor-container elementor-column-gap-default">
    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ec04429" >
     <div class="elementor-widget-wrap elementor-element-populated">
      <div class="elementor-element elementor-element-837fb42 ob-harakiri-inherit elementor-widget elementor-widget-heading">
       <div class="elementor-widget-container">
        <h1 class="elementor-heading-title elementor-size-default">Term of use</h1>
       </div>
      </div>
      <div class="elementor-element elementor-element-cede374 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list">
       <div class="elementor-widget-container">
        <ul class="elementor-icon-list-items elementor-inline-items">
         <li class="elementor-icon-list-item elementor-inline-item"> <span class="elementor-icon-list-text">Home</span> </li>
         <li class="elementor-icon-list-item elementor-inline-item"> <span class="elementor-icon-list-icon icon-align"> <i class="fas fa-arrow-right font-awesome-pro"></i> <span class="elementor-icon-list-text">Term of use</span> </li>
        </ul>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>

	  <!-- Start Works About 
    ============================================= -->
    <div class="works-about-area">
        <div class="container">
            <div class="works-about-items default-padding">
                <div class="row align-center">
                    <div class="col-lg-12 info">
                        <h2>Term of use</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                 
                </div>
            </div>
        </div>
    </div>
 </div>
</div>

<?php $this->load->view('frontend/layout/footer'); ?>